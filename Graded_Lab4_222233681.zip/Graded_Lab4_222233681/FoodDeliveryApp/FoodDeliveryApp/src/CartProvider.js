
console.log('Current Cart:', cart);

